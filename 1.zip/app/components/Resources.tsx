interface ResourcesProps {
  snot: number;
  snotCoins: number;
  containerCapacity: number;
  containerLevel: number;
  containerSnot: number;
  onContainerUpgrade?: () => void;
} 