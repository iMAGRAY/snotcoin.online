'use client';

import DevToolsNew from './DevToolsNew';

// Экспортируем новый компонент
export default DevToolsNew; 