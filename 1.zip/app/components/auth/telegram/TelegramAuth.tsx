"use client"

import React, { useEffect, useState } from 'react';
import { TelegramAuthProps, AuthStatus } from '../../../types/telegramAuth';
import { useTelegramAuth } from '../../../hooks/useTelegramAuth';
import TelegramAuthLoader from './TelegramAuthLoader';
import TelegramAuthError from './TelegramAuthError';
import { AuthLogType, AuthStep, logAuth, logAuthError, logAuthInfo } from '../../../utils/auth-logger';

/**
 * Компонент для аутентификации через Telegram
 */
const TelegramAuth: React.FC<TelegramAuthProps> = ({ onAuthenticate }) => {
  // Используем хук для логики аутентификации
  const {
    user,
    status,
    isLoading,
    handleAuth,
    handleRetry,
    closeWebApp,
    openInTelegram,
    errorMessage
  } = useTelegramAuth(onAuthenticate);
  
  // Состояние для отслеживания попыток аутентификации
  const [authAttempts, setAuthAttempts] = useState<number>(0);
  const [isRetrying, setIsRetrying] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  
  // Выполняем аутентификацию при монтировании компонента
  useEffect(() => {
    logAuthInfo(AuthStep.INIT, 'Инициализация компонента TelegramAuth');
    
    const authenticate = async () => {
      logAuthInfo(AuthStep.TELEGRAM_INIT, 'Запуск процесса Telegram авторизации');
      
      try {
        setIsRetrying(true);
        
        // Пытаемся авторизовать пользователя через Telegram
        const result = await handleAuth();
        
        if (result) {
          logAuthInfo(AuthStep.AUTH_COMPLETE, 'Процесс авторизации завершен успешно');
          handleAuthSuccess(user);
        } else {
          logAuthError(
            AuthStep.AUTH_ERROR,
            'Процесс авторизации завершен с ошибкой',
            new Error(errorMessage || 'Неизвестная ошибка')
          );
          
          // Если авторизация не удалась, увеличиваем счетчик попыток
          setAuthAttempts(prev => prev + 1);
        }
      } catch (error) {
        logAuthError(
          AuthStep.AUTH_ERROR,
          'Ошибка при авторизации через Telegram',
          error as Error
        );
        setAuthAttempts(prev => prev + 1);
      } finally {
        setIsRetrying(false);
      }
    };
    
    // Запускаем процесс авторизации
    authenticate();
    
    // Отписываемся при размонтировании
    return () => {
      logAuthInfo(AuthStep.USER_INTERACTION, 'Компонент TelegramAuth размонтирован');
    };
  }, [handleAuth, status, errorMessage]);
  
  const handleAuthSuccess = (user: any) => {
    logAuthInfo(AuthStep.TELEGRAM_SUCCESS, 'Успешная авторизация через Telegram');
    onAuthenticate(user);
  };

  const handleAuthError = (error: Error) => {
    logAuthError(
      AuthStep.TELEGRAM_ERROR,
      'Ошибка авторизации через Telegram',
      error
    );
    setError(error.message);
  };

  const handleAuthRetry = () => {
    logAuthInfo(AuthStep.AUTH_RETRY, 'Повторная попытка авторизации');
    setError(null);
    setAuthAttempts(prev => prev + 1);
  };
  
  // Обработчик закрытия Telegram WebApp
  const handleCloseWebApp = () => {
    logAuth(
      AuthStep.USER_INTERACTION, 
      AuthLogType.INFO, 
      'Пользователь закрыл WebApp', 
      { status }
    );
    closeWebApp();
  };
  
  // Обработчик открытия в Telegram
  const handleOpenInTelegram = () => {
    logAuth(
      AuthStep.USER_INTERACTION, 
      AuthLogType.INFO, 
      'Пользователь выбрал открытие в Telegram', 
      { status }
    );
    openInTelegram();
  };
  
  // Отображаем загрузчик при загрузке
  if (isLoading || status === AuthStatus.LOADING || isRetrying) {
    logAuthInfo(AuthStep.USER_INTERACTION, 'Отображение загрузчика авторизации', { isRetrying, authAttempts });
    return <TelegramAuthLoader />;
  }
  
  // Отображаем компонент ошибки при ошибке
  if (status === AuthStatus.ERROR) {
    logAuthError(
      AuthStep.AUTH_ERROR,
      'Отображение компонента ошибки авторизации',
      error ? new Error(error) : new Error('Неизвестная ошибка')
    );
    
    return (
      <TelegramAuthError 
        errorMessage={error || undefined}
        onRetry={handleAuthRetry}
        onClose={handleCloseWebApp}
        onOpenInTelegram={handleOpenInTelegram}
        attemptCount={authAttempts}
      />
    );
  }
  
  // В случае успешной авторизации, возвращаем null (дочерние компоненты будут отрисованы родителем)
  logAuthInfo(AuthStep.AUTH_COMPLETE, 'Авторизация успешна, возвращаем null для продолжения');
  return null;
};

export default TelegramAuth;