/**
 * Экспорт провайдеров игры
 */
export { default as GameProvider } from './GameProvider'; 