/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true, // Включаем Strict Mode обратно
  // Add other Next.js configurations here if needed
};

module.exports = nextConfig; 